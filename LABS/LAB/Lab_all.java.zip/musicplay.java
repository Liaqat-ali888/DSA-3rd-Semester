class Node {
	String songName;
	String artistName;
	Node next;
	Node prev;
	Node (String songName, String artistName){
		this.songName = songName;
		this.artistName = artistName;
		this.next = null;
		this.prev = null;
	}
	void displays(){
		System.out.print("["+songName+" by "+artistName+"]"+"->");
	}
}
class palylist{
	Node head;
	Node tail;
	Node currentplay;
	boolean loopMode;
	palylist(){
		this.head = null;
		this.tail = null;
   		this.currentplay = null;
        this.loopMode = false;
	}
void addSong(String songName, String artistName ){
	Node newsong = new Node(songName , artistName);
	if(head == null){
		head = newsong;
		tail = newsong;
		tail.next = head;
		tail.prev = head;
		return; 
	}
	newsong.next = head;
	head.prev = newsong;
	head = newsong;
	tail.next = newsong;
	currentplay = head;
	currentplay.prev = newsong;
}
void delete(String song){
	if(head == null){
		System.out.println("emty the palylist");
		return;
	}
	if(song.equals(head.songName)){
		head.displays();
		System.out.println("deleted successfully\n");
		head = head.next;
		head.prev = null;
		tail.next = head;
		currentplay = head;
		currentplay.prev = null;
	}
	if(song.equals(tail.songName)){
		tail.displays();
		System.out.println("deleted successfully\n");
	tail.prev.next = tail.next;
	tail = tail.prev; 
	}

Node cur = head;
while(cur!=tail){
	if(song.equals(cur.songName)){
		cur.displays();
		System.out.println("deleted successfully\n");
		cur.prev.next = cur.next;
		cur.next.prev = cur.prev;
		return;
	}
	cur = cur.next;
}
System.out.println("Not found to delete");
}
void search(String song){
	if(head ==null ){
   System.out.println("playlist is  empty");
   return;
	}
	if(head.songName.equals(song)){
		head.displays();
			return;
	}
	if(tail.songName.equals(song)){
		tail.displays();
		return;
	}
	Node cur = head;
	while(cur!= tail)
	{
		if(cur.songName.equals(song)){
			cur.displays();
			return;
		}
		cur =  cur.next;
	}
	 System.out.println("Not found");
}
void playNext(){
 if(head == null){
 	System.out.println("list is empty ");
 	return;
 }
  

 System.out.println("\ncurrent playing...");
 
 currentplay.displays();

 if(currentplay == tail){
 	if(loopMode){
 		currentplay = head;
 	}
 	else{
 		System.out.println("\n reached the last song.");
 		return;
 	}
 

 }
 	else {
 		 currentplay = currentplay.next;
 	}

	}
	void playPrevious(){
		if(head == null){
			System.out.println("nothing to play in list");
			return;
		}
		 System.out.println("\nprevius playing ");
		
	
	 if(currentplay == head){
	 	if(loopMode){
	 		currentplay =tail;
	 	}
		 	else{System.out.println("You reach the first song....");
		 	return;
		 }
         
	}
	else{
		currentplay = currentplay.prev;
	}
	currentplay.displays();

	}

	void toggleLoopMode(){
		loopMode = !loopMode;
		if(loopMode){
			System.out.println("Loop mode: on");
		}
		else{
			System.out.println("Loop Mode: off");
		}
	}


void displayPlaylist(){
	Node cur = head;
if(head == null){
	System.out.println("play list empty");
    return;
}
    while(cur!=tail){
    	cur.displays();
    	cur = cur.next;
    }
   tail.displays();

}

void displayReversePlaylist(){
	Node cur = tail;
	while(cur!=head.prev){
		cur.displays();
		cur =  cur.prev;
	}
	head.displays();

}
}
class main{
	public static void main(String art[]){
		palylist list = new palylist();
		list.addSong("Balti song","liaqat ali");

		list.addSong("Gilgitii song","noorima");

		list.addSong("urdu ghazal","maisam");
		list.addSong("shina song","mushu");
		list.addSong("bursheski song","ayaz");
		list.addSong("pashto song","okasha");
		

		System.out.println("\nDelete the song");
		list.delete("shina song");
		//list.display();
		System.out.println("\nSearching......");
		list.search("Gilgitii song");
		System.out.println("\n");
		list.displayPlaylist();
System.out.println("\n\n\n");
list.toggleLoopMode();
		list.playNext();
		list.playNext();
	
			list.playPrevious();
			list.playPrevious();
	list.displayReversePlaylist();
	

	}
}