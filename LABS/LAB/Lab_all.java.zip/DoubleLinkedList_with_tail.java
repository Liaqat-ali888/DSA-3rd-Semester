class Node{
	int data;
	Node next;
	Node prev;
	Node(int data ){
		this.data = data;
		this.next = null;
		this.prev = null;
	}
	
}
class DoubleLinkedList{
	Node head;
	Node tail;
	DoubleLinkedList(){
		this.head = null;
		this.tail=null;
	}



void addBack(int data){
	 Node newNode = new Node(data);
     if(head == null){
            head = newNode;
            tail = newNode;
            tail.prev=head;
            head.prev = tail;
           tail.next = head;
            return;
        }
        tail.next = newNode;
        newNode.prev = tail;
        tail = newNode;
}
 void deleteFront(){
        if(head == null){
        System.out.println("Empty lsit!!");
        return;
    }

    head.prev = null;
    head = head.next; 
  }

  void deleteBack(){
    
      if(head == null){
        System.out.println("Empty lsit!!");
        return;
    }
    if(tail.prev == head){
        head=null;
        tail=null;
        return;

    }
     tail = tail.prev;
     tail.next =null;

   }

void seachNode(int id){
        Node cur = head;
    if(head.data == id){
        System.out.println(head.data);
        return;
    }
    while(cur.next!=null){
       cur = cur.next;
        if(cur.data ==id){
            System.out.println(cur.data);
            return;
        }
       
    }
    System.out.println("\nNot fount node!!");
  }

 void deleteNode(int id)
    {
        if(head == null){
            System.out.println("list empty");
        }
        else if(head.data==id){
            deleteFront();
        }
        else if(tail.data==id){
            deleteBack();
            return;
        }
        else{
            Node current = head;
            while(current!=tail){
                if(current.data== id){
                    current.prev.next = current.next;
                    current.next.prev = current.prev.next;
                    return;
                }
                current =current.next;
            }

         }
     }
      void addAfter(int id,int s){
      Node newNode = new Node(s);
    if(head==null){
        System.out.println("Empty list Nothing to delete!!");
        return; }
      if(head.data == id){
         newNode.next = head.next;
         head.next.prev = newNode;
         head.next = newNode;
         newNode.prev = head;
         return;}
    if(tail.data == id){
         addBack(s);
         return;   }
    Node current = head;
    while(current!=tail){
        if(current.data ==id){
          newNode.next = current.next;
          current.next.prev = newNode;
          newNode.prev =  current;
          current.next = newNode;
            return ;
        }
        current = current.next;   }
    }
    void addBefore(int id,int s){
     Node newNode = new Node(s);
    if(head==null){
        System.out.println("Empty list Nothing to delete!!");
        return;
    }
    Node cur = head;
    if(head.data == id){
       newNode.next = head;
       head.prev = newNode;
       head=newNode; 
      // tail.next = head;
       return;  
    }
    while(cur!=null){
        if(cur.data== id){
            newNode.next = cur;
            cur.prev.next = newNode;
            newNode.prev = cur.prev;
            cur.prev = newNode;
              return;
        }
        cur = cur.next;
    }

}

  void displayData(){
	  if(head == null){
            System.out.println("list is empty");
            return;
        }
        Node current = head;
        while(current!=null){
        
		System.out.print(current.data +"->");
	
            current = current.next;


        }
}
 void update(int id, int data){
        if(head == null){
            System.out.println("list empty");
            return;
        }

        Node newNode = head;
        while(newNode!=tail.next){
            if(newNode.data==id){
                newNode.data =data;
                System.out.println("updated student record");
                return;

            }
            newNode  = newNode.next;
        }
        System.out.println("SID  " + id + " not found");
    } 

void displayBackward(){
	 if(head == null){
            System.out.println("list is empty");
            return;
        }
        Node current = tail;

        while(current.prev!=null){
        
		System.out.print(current.data +"->");
	
            current = current.prev;
        }
      

}


}
class main{
	public static void main(String arg[]){
		DoubleLinkedList list = new DoubleLinkedList();
		list.addBack(0);
		list.addBack(1);
		list.addBack(2);
		list.addBack(3);
		list.addBack(4);
		list.addBack(5);
		list.displayData();
		System.out.println("\nAfter Deleted Front");
		list.deleteFront();
		list.displayData();
		System.out.println("\nAfter Deleted Back");
		list.deleteBack();
		list.displayData();
		System.out.println("\nSearch Data");
		list.seachNode(4);
		System.out.println("\n Deleted though data");
		list.deleteNode(3);
		list.displayData();
  
  System.out.println("\n Add after");
	   list.addAfter(2,3);
		list.displayData();
       

  System.out.println("\n add before");
	   list.addBefore(4,5);
		list.displayData();

		System.out.println("\n Display Forward");
		list.displayData();
		System.out.println("\n Display Backward");
		list.displayBackward();
        System.out.println("update!!");
		list.update(4,99);
		list.displayData();
	
	}
}